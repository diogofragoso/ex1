﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace $safeprojectname$
{
    class Program
    {

     

        static void Main(string[] args)
        {

            Conexao conectando = new Conexao();

            conectando.conectar();
            Console.WriteLine("Ola deu certo");
            Console.ReadKey();


        }
    }
}
