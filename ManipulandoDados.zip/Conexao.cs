﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace $safeprojectname$
{

   



    class Conexao
    {
        public void conectar()
        {

            String nomeDS = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\diogo\Documents\bd05_teste.mdf;Integrated Security=True;Connect Timeout=30";

            SqlDataAdapter da = new SqlDataAdapter("SELECT id,nome_Produto,id_marcaProduto,descricao FROM Produto", nomeDS);

            ProdutoDS produtoData = new ProdutoDS();
            da.Fill(produtoData,"Produto");

            SqlConnection conectando = new SqlConnection(nomeDS);
            
            Console.WriteLine(produtoData.Produto[0].nome_Produto);
            Console.WriteLine(produtoData.Produto[1].nome_Produto);
            
            da.Update(produtoData);
            da.UpdateCommand = new SqlCommand("UPDATE Categories SET CategoryName = @CategoryName " + "WHERE CategoryID = @CategoryID", conectando);
            Console.WriteLine("parada");


            


        }




    }
}
